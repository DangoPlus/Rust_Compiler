# **How to build**
    make
    ./proj2 <testfiles
    make clean
## changes
1. lex file 

    change print to return

2. yacc file 

    write gramar and modify symbol table
