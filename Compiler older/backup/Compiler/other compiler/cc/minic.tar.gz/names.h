#ifndef	NAMES_H
#define	NAMES_H
/*	names.h(1.1)	09:25:08	97/12/08
*
*	String pool management.
*/
char*	names_insert(char*);
char*	names_find(char*);
char*	names_find_or_add(char*); 

#endif
