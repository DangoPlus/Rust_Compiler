// Hello World Example

func void main ( ) {
    println "Hello World"
}