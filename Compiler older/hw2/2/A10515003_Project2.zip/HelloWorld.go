// Hello World Example

func main ( ) {
    println "Hello World"
}
