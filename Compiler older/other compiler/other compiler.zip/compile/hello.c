#include <stdio.h>
int fun(int f);
void main(int argc,char *argv)
{	
	int x;
	int z;
	int a;
	int saa;
	int y[3];//dasdjalkdjsljaklsdjdjaslk
	char b;
	z=1.79173891239;
	a=111;
	b=1;
	x=222;
	saa=3;
	a=(a+x)/saa;
	if(a>111){
		b=2;
		if(b>3){
			b=4;
		}
		x=5;
	}
	return a;
	
	//__stdcall("adsada");
}
