#ifndef	UTIL_H
#define	UTIL_H
/*
*	util.h(1.1)	11:24:32	97/12/08 	
*
*	General utility functions
*/
#include	<stdlib.h>

void	*fmalloc(size_t);	/* malloc() version that aborts on failure */

#endif
