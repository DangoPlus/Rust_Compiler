#ifndef _BASIC_H
#define _BASIC_H

#include <unistd.h>

#define WRITES(FD,S) write(FD,S,sizeof(S))

#endif
